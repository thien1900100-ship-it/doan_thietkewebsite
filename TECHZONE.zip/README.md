# TECHZONE - DỰ ÁN WEBSITE THƯƠNG MẠI ĐIỆN TỬ ĐỒ CÔNG NGHỆ

Gói mã nguồn đầy đủ đồ án công nghệ TECHZONE:
1. database/schema.sql : Cấu trúc cơ sở dữ liệu MySQL 8.0+
2. database/seed.sql : Dữ liệu mẫu hơn 30 sản phẩm công nghệ, 9 danh mục, đơn hàng và tài khoản
3. TECHZONE_Flask_Backend/ : Mã nguồn hoàn chỉnh Backend Python Flask + SQLAlchemy + JWT
4. Xem hướng dẫn cài đặt và chạy trong file TECHZONE_Flask_Backend/README.md

Tài khoản đăng nhập kiểm thử:
- Admin: admin@techzone.vn / admin123
- Khách hàng: khachhang@techzone.vn / user123
